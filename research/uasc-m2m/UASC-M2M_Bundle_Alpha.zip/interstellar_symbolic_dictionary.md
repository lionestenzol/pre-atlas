# Interstellar Symbolic Dictionary (UASC-M2M)

## Subsystem Strokes

- `一` → **TRAJECTORY_CONTROL** — Adjust navigation, perform course corrections
- `丨` → **SENSOR_SYSTEMS** — Collect stellar/environmental/atmospheric data
- `丿` → **DATA_TRANSMISSION** — Transmit data packets, telemetry to Earth
- `乀` → **SYSTEM_DIAGNOSTICS** — Health check, module scanning
- `乙` → **RESOURCE_ALLOCATION** — Distribute power, fuel, computation
- `丶` → **EMERGENCY_PROTOCOL** — Activate failsafe, fallback, or safe mode

## Contextual Modifiers

- `丨丨` — Perform tasks in parallel
- `丿丶` — Optional mission step
- `一一丨` — Critical maneuver
- `丶丶` — Emergency override mode