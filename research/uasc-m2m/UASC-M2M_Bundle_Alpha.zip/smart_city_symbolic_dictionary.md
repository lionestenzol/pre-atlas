# Smart City Symbolic Dictionary (UASC-M2M)

## Subsystem Strokes

- `一` → **TRAFFIC_CONTROL** — Route optimization, signal control
- `丨` → **POWER_GRID** — Load balance, energy routing
- `乀` → **EMERGENCY_SERVICES** — Dispatch units, trigger response
- `丶` → **PUBLIC_TRANSIT** — Bus/train command, route adjust
- `乙` → **WATER_MANAGEMENT** — Flow control, leak detection
- `丿` → **DATA_SENSOR_NET** — Environment data polling

## Contextual Modifiers

- `丨丨` — Execute in parallel
- `丿丶` — Optional/soft trigger
- `一一丨` — Critical override
- `丶丶` — Emergency priority