# UASC-M2M Encoding & Decoding Specification

This document defines how glyphs are interpreted in the UASC-M2M language system.

---

## 1. GLYPH STRUCTURE

Each glyph is composed of one or more **primitive strokes** that represent core execution semantics.

- A glyph may contain **1 to 6 strokes**.
- The **order of strokes** determines the flow and logic structure.
- Strokes are interpreted sequentially from **top-left to bottom-right** in traditional writing order.

---

## 2. STROKE TO LOGIC MAPPING

Refer to the [Symbolic Dictionary](./uasc_symbolic_dictionary.md) for full definitions.

| Stroke | Meaning              | Function Example          |
|--------|----------------------|---------------------------|
| 一     | Sequential Execution | Move to next instruction  |
| 丨     | Conditional Check    | If-condition statement    |
| 丿     | Data Retrieval       | Pull from database/cache  |
| 乀     | Data Storage         | Save to memory/storage    |
| 乙     | Iterative Loop       | Begin/end loop block      |
| 丶     | Termination          | Confirm or halt process   |

---

## 3. GLYPH DECODING PROTOCOL

### EXAMPLE: "耀" (Yào)
A multi-stroke glyph might represent:
- 一 → Initialize process
- 丨 → Run condition check
- 乙 → Loop or repeat
- 乀 → Save result
- 丶 → Confirm and terminate

**Decoded logic**:
```
Start → If condition → Loop → Store result → End
```

---

## 4. COMPOUND STRUCTURES

Certain glyphs may be interpreted as **logic macros** using compound patterns:

- **ACTION_SEQUENCE** → 一 + 一 + 一
- **CONDITIONAL_BRANCH** → 丨 + 丿 + 乀
- **ITERATIVE_LOOP** → 乙 + 一 + 丨
- **ERROR_HANDLER** → 乀 + 丶 + 丨

---

## 5. CONTEXTUAL MODIFIERS

Contextual strokes affect the meaning of surrounding strokes:

- `丿丶` → Optional execution
- `丨丨` → Parallel threads
- `一一丨` → Critical execution path
- `丶` (when duplicated) → Escalated priority

---

## 6. GLYPH AS APPLICATIONS

Glyphs can represent entire **mini-apps** or **command scripts**. A decoder agent will:
1. Analyze stroke order
2. Map to logic sequence
3. Execute or simulate the resulting behavior

---

## 7. NOTES FOR IMPLEMENTATION

- Glyphs are *not* static—they change meaning based on position and context.
- Decoders must consider **stroke priority**, **modifier presence**, and **domain context** (Smart City, Military, etc.)

This specification enables AI-driven interpreters and n8n workflows to decode, simulate, and execute full logic chains from a single glyph.