# UASC-M2M Symbolic Dictionary

## PRIMITIVE STROKES

- `一` (HORIZONTAL): Sequential Execution
- `丨` (VERTICAL): Conditional Check
- `丿` (DIAGONAL_LEFT): Data Retrieval
- `乀` (DIAGONAL_RIGHT): Data Storage
- `乙` (HOOK): Iterative Loop
- `丶` (DOT): Process Termination

## COMPOUND STROKE GROUPINGS

- **ACTION_SEQUENCE**: 一 + 一 + 一
- **CONDITIONAL_BRANCH**: 丨 + 丿 + 乀
- **ITERATIVE_LOOP**: 乙 + 一 + 丨
- **ERROR_HANDLER**: 乀 + 丶 + 丨
- **DATA_FLOW**: 丿 + 乀 + 丿

## CONTEXTUAL MODIFIERS

- **PRIORITY_MARKER**: `丶`
- **PARALLEL_EXECUTION**: `丨丨`
- **OPTIONAL_OPERATION**: `丿丶`
- **CRITICAL_PATH**: `一一丨`